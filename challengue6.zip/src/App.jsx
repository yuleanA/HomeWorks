import Counter from "./counter";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Counter value={0} />
    </div>
  );
}
