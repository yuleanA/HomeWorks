import { GifExpertApp } from "./GiftExpertApp";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <GifExpertApp />
    </div>
  );
}
