import FirstApp from "./FirstApp";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <FirstApp title="Challengue 1" sum="10" />
    </div>
  );
}
