import FirstApp from "./FirstApp";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <FirstApp value={0} />
    </div>
  );
}
