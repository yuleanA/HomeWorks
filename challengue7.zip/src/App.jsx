import { MultipleCustomHook } from "./components/MultipleCustomHooks";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <MultipleCustomHook />
    </div>
  );
}
